# Changelog

## 1.0.2 (UE 5.8)

- Rebuilt the Win64 editor binary against Unreal Engine 5.8.3 with the current toolchain;
  the shipped DLL loads and the module initializes cleanly (verified in-editor).
- Panel header is always visible: a Nous Portal account link (Google, Microsoft or GitHub
  sign-up and account management) plus **Open in browser** and **Reload** controls, so a
  blank or stale panel can be recovered without restarting the editor.
- Fixed a blank-panel failure caused by the web UI being reached before the local Hermes
  server was ready; the panel now starts the local dashboard itself and reloads once it
  answers.
- `PlatformAllowList` narrowed to Win64, matching the shipped binary.
- Documentation: BuildPlugin packaging instructions for UE 5.4 - 5.8 added to BUILDING.md.

### Notes on accounts

The panel talks to your own Hermes dashboard on `127.0.0.1:9119`, which does not require a
Nous account. The header link opens the Portal in your normal browser for account and
subscription management; it is not a sign-in for the editor panel itself.

## 1.0.1 (UE 5.8)

- Pre-compiled binaries, blank-panel fix, Blueprint export library (`UHermesExportLibrary`).

## 1.0.0

- Initial release: embedded Hermes Agent panel, asset exporter, console commands.
