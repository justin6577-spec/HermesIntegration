// Copyright (c) 2026 Justin. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "HAL/PlatformProcess.h"
#include "Containers/List.h"

class FHermesManager : public TSharedFromThis<FHermesManager>
{
public:
	FHermesManager();
	~FHermesManager();

	void Initialize();
	void Shutdown();

	bool IsHermesRunning() const;
	bool EnsureHermesRunning();
	FString GetHermesURL() const;
	/** True when the manager knows a valid Hermes port and URL (always for this build). */
	bool IsHermesURL() const { return GetHermesPort() > 0; }
	uint16 GetHermesPort() const { return 9119; }

	// Fresh, non-cached liveness probe: attempts a loopback TCP connect to the
	// Hermes port right now. Unlike IsHermesRunning() (which returns a cached
	// flag set optimistically the moment the process is spawned), this reflects
	// whether the server has actually finished binding the port, so it is safe
	// to poll from the panel while waiting for `hermes serve` to come up.
	// Thread-safe: creates and destroys its own socket, touches no members.
	bool IsServerResponding() const { return CheckPortAvailable(GetHermesPort()); }

	void SetZoomLevel(float ZoomLevel);
	float GetZoomLevel() const;

private:
	bool DetectHermesRunning();
	bool StartHermesProcess();
	void StopHermesProcess();
	bool CheckPortAvailable(uint16 Port) const;

	FProcHandle HermesProcessHandle;
	bool bHermesRunning;
	float StoredZoomLevel;
	FString HermesExecutablePath;
	FString HermesConfigDir;
};
