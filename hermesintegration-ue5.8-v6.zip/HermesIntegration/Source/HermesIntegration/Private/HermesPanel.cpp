// Copyright (c) 2026 Justin. All Rights Reserved.

#include "HermesPanel.h"
#include "HermesManager.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Layout/SSpacer.h"
#include "Widgets/Input/SHyperlink.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Text/STextBlock.h"
#include "SWebBrowser.h"
#include "Styling/AppStyle.h"
#include "Async/Async.h"
#include "HAL/PlatformProcess.h"

/** Nous Research portal sign-in. Hosts the Google / Microsoft / GitHub / email / Discord
 *  social logins, so a user without dashboard credentials can sign in there and come back
 *  to the panel already authenticated. */
static const TCHAR* NousPortalLoginURL = TEXT("https://portal.nousresearch.com/login");

void SHermesPanel::Construct(const FArguments& InArgs)
{
	HermesManager = InArgs._HermesManager;

	ChildSlot
	[
		SNew(SBorder)
		.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
		.Padding(2.0f)
		[
			SNew(SVerticalBox)

			// Header strip: account sign-in link + browser controls. Always visible, so the
			// social-login route is reachable even while the panel shows the login page.
			+ SVerticalBox::Slot()
			.AutoHeight()
			.Padding(4.0f, 2.0f)
			[
				SNew(SHorizontalBox)

				+ SHorizontalBox::Slot()
				.AutoWidth()
				.VAlign(VAlign_Center)
				.Padding(4.0f, 0.0f)
				[
					SNew(STextBlock)
					.Text(FText::FromString(TEXT("Nous Portal account:")))
					.Font(FAppStyle::GetFontStyle("SmallFont"))
					.ColorAndOpacity(FSlateColor::UseSubduedForeground())
				]

				+ SHorizontalBox::Slot()
				.AutoWidth()
				.VAlign(VAlign_Center)
				.Padding(2.0f, 0.0f)
				[
					SNew(SHyperlink)
					.Text(FText::FromString(TEXT("Sign up / manage account (Google - Microsoft - GitHub)")))
					.ToolTipText(FText::FromString(TEXT("Opens the Nous Portal in your web browser to create a free account or manage your subscription with Google, Microsoft, GitHub, email, or Discord. The panel itself needs no account when the dashboard runs on localhost.")))
					.OnNavigate_Lambda([]()
					{
						FPlatformProcess::LaunchURL(NousPortalLoginURL, nullptr, nullptr);
					})
				]

				+ SHorizontalBox::Slot()
				.FillWidth(1.0f)
				[
					SNew(SSpacer)
				]

				+ SHorizontalBox::Slot()
				.AutoWidth()
				.VAlign(VAlign_Center)
				.Padding(2.0f, 0.0f)
				[
					SNew(SButton)
					.ContentPadding(FMargin(6.0f, 2.0f))
					.ToolTipText(FText::FromString(TEXT("Open the Hermes dashboard in your default browser.")))
					.OnClicked_Lambda([this]()
					{
						if (HermesManager.IsValid())
						{
							const FString URL = HermesManager->GetHermesURL();
							FPlatformProcess::LaunchURL(*URL, nullptr, nullptr);
						}
						return FReply::Handled();
					})
					[
						SNew(STextBlock)
						.Text(FText::FromString(TEXT("Open in browser")))
						.Font(FAppStyle::GetFontStyle("SmallFont"))
					]
				]

				+ SHorizontalBox::Slot()
				.AutoWidth()
				.VAlign(VAlign_Center)
				.Padding(2.0f, 0.0f)
				[
					SNew(SButton)
					.ContentPadding(FMargin(6.0f, 2.0f))
					.ToolTipText(FText::FromString(TEXT("Reload the panel (e.g. after changing dashboard settings or starting the local Hermes server).")))
					.OnClicked_Lambda([this]()
					{
						if (WebBrowser.IsValid() && HermesManager.IsValid())
						{
							WebBrowser->LoadURL(HermesManager->GetHermesURL());
						}
						return FReply::Handled();
					})
					[
						SNew(STextBlock)
						.Text(FText::FromString(TEXT("Reload")))
						.Font(FAppStyle::GetFontStyle("SmallFont"))
					]
				]
			]

			+ SVerticalBox::Slot()
			.FillHeight(1.0f)
			[
				SAssignNew(WebBrowser, SWebBrowser)
				.InitialURL(TEXT("about:blank"))
				.ShowControls(true)
				.ShowAddressBar(false)
				.SupportsTransparency(false)
			]
		]
	];

	// Start with about:blank so CEF never shows a "failed to load" error page.
	// Once the Hermes server actually responds, load the real URL.
	if (HermesManager.IsValid() && HermesManager->IsHermesURL())
	{
		FString URL = HermesManager->GetHermesURL();
		const bool bReadyNow = HermesManager->IsServerResponding();

		if (bReadyNow)
		{
			WebBrowser->LoadURL(URL);
		}
		else
		{
			TWeakPtr<FHermesManager> WeakManager = HermesManager;
			TWeakPtr<SWebBrowser> WeakBrowser = WebBrowser;
			Async(EAsyncExecution::ThreadPool, [WeakManager, WeakBrowser, URL]()
			{
				for (int32 Attempt = 0; Attempt < 60; ++Attempt)
				{
					TSharedPtr<FHermesManager> Manager = WeakManager.Pin();
					if (!Manager.IsValid()) return;
					if (Manager->IsServerResponding())
					{
						AsyncTask(ENamedThreads::GameThread, [WeakBrowser, URL]()
						{
							if (TSharedPtr<SWebBrowser> Browser = WeakBrowser.Pin())
							{
								Browser->LoadURL(URL);
							}
						});
						return;
					}
					FPlatformProcess::Sleep(0.5f);
				}
			});
		}
	}
}
