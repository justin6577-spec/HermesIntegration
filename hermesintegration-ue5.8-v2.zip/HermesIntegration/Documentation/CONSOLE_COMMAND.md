# Hermes Integration — Console Command

In addition to the toolbar button, the plugin registers a console command so the panel can always be opened from the Output Log — useful on custom editor layouts where the Level Editor toolbar extension is not visible.

## Opening the Hermes Panel

In the Unreal Editor, open **Window → Output Log** and run:

```
Hermes.Open
```

This will:
- Create a floating window (800x600) titled "Hermes"
- Load the Hermes web UI from `http://127.0.0.1:9119`
- Bring the existing window to the front if one is already open (no duplicates)

## Command Details

| | |
|---|---|
| **Command** | `Hermes.Open` |
| **Registered by** | the HermesIntegration editor module at startup |
| **Repeatable** | Yes — reuses the existing window if open |

## Troubleshooting

### "Unknown Command" when running Hermes.Open
- The plugin may not have loaded. Filter the Output Log for `LogHermes` — a successful load prints `HermesIntegration module loaded`.
- Confirm the plugin is enabled under **Edit → Plugins → Editor** and the editor was restarted.

### Window opens but the page is blank
- The Hermes server may not be running or still initializing. Wait a few seconds, then check it responds: `curl http://127.0.0.1:9119`
- Start it manually if needed: `hermes serve --port 9119 --host 127.0.0.1`
