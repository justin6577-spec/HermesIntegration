# Hermes Integration — Quick Start

Get from a fresh install to a working Hermes panel in about five minutes.

## 1. Prerequisites

- Unreal Engine 5.8
- Hermes Agent installed (https://hermes-agent.nousresearch.com/) and configured with `hermes setup`
- The Hermes Integration plugin enabled in your project (**Edit → Plugins → Editor**, then restart)

## 2. Open the Panel

1. In the Level Editor, look for the **Hermes** button in the main toolbar (near the Play controls).
2. Click it — a floating 800x600 window titled "Hermes" opens with the Hermes web UI.
3. Alternatively, open the Output Log and run the console command `Hermes.Open`.

If no Hermes server is running, the plugin starts one for you (`hermes serve --port 9119`). The first launch can take a couple of seconds.

## 3. Verify Everything Works

- **Type a message** in the Hermes chat box — you should get a response from your configured model/provider.
- **Close and reopen** the window — reopening brings the panel back without errors; if the window is already open, it is brought to the front.

### Check the server manually (optional)

```bash
curl -s http://127.0.0.1:9119 | head -5     # should return HTML
```

### Check the editor log (optional)

Open **Window → Output Log** and filter for `LogHermes`. On a successful load you'll see:

```
LogHermes: HermesIntegration module loaded - use 'Hermes.Open' console command to open panel
```

## 4. Troubleshooting

### Hermes button not visible
- Confirm the plugin is enabled and the editor was restarted.
- Use the `Hermes.Open` console command as an alternative.

### Window opens but the UI is blank
- Verify the server responds: `curl http://127.0.0.1:9119`
- Start it manually: `hermes serve --port 9119 --host 127.0.0.1`

### Hermes server fails to start
- Ensure `hermes` is in your PATH: `which hermes` (or `where hermes` on Windows)
- Check whether port 9119 is already in use by another application.

### More help
- See `README.md` in this folder for details on how the plugin works.
- Hermes Agent issues: https://github.com/NousResearch/hermes-agent/issues
