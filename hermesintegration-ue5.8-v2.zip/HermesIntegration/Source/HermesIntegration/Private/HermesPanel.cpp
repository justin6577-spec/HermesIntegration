// Copyright (c) 2026 Justin. All Rights Reserved.

#include "HermesPanel.h"
#include "HermesManager.h"
#include "Widgets/Layout/SBorder.h"
#include "SWebBrowser.h"
#include "Styling/AppStyle.h"

void SHermesPanel::Construct(const FArguments& InArgs)
{
	HermesManager = InArgs._HermesManager;

	FString URL = TEXT("about:blank");
	if (HermesManager.IsValid())
	{
		URL = HermesManager->GetHermesURL();
	}

	ChildSlot
	[
		SNew(SBorder)
		.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
		.Padding(2.0f)
		[
			SAssignNew(WebBrowser, SWebBrowser)
			.InitialURL(URL)
			.ShowControls(true)
			.ShowAddressBar(false)
			.SupportsTransparency(false)
		]
	];
}
