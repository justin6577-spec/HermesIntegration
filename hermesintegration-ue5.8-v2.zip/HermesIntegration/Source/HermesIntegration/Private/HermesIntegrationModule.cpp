// Copyright (c) 2026 Justin. All Rights Reserved.

#include "HermesIntegrationModule.h"
#include "HermesManager.h"
#include "HermesPanel.h"
#include "HermesIntegration.h"
#include "Framework/Application/SlateApplication.h"
#include "HAL/IConsoleManager.h"
#include "Styling/AppStyle.h"
#include "ToolMenus.h"
#include "Widgets/SWindow.h"

#define LOCTEXT_NAMESPACE "FHermesIntegrationModule"

DEFINE_LOG_CATEGORY(LogHermes);

static FHermesIntegrationModule* GSingletonModule = nullptr;

void FHermesIntegrationModule::StartupModule()
{
	GSingletonModule = this;

	HermesManager = MakeShared<FHermesManager>();
	HermesManager->Initialize();

	// Register toolbar button once the ToolMenus system is ready
	UToolMenus::RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FHermesIntegrationModule::RegisterToolbarButton));

	// Register console command as fallback
	HermesOpenCommand = IConsoleManager::Get().RegisterConsoleCommand(
		TEXT("Hermes.Open"),
		TEXT("Open the Hermes AI Assistant panel"),
		FConsoleCommandDelegate::CreateRaw(this, &FHermesIntegrationModule::OnToggleHermesPanel),
		ECVF_Default
	);

	UE_LOG(LogHermes, Log, TEXT("HermesIntegration module loaded - use 'Hermes.Open' console command to open panel"));
}

void FHermesIntegrationModule::ShutdownModule()
{
	UToolMenus::UnRegisterStartupCallback(this);
	if (UToolMenus* ToolMenus = UToolMenus::TryGet())
	{
		ToolMenus->UnregisterOwner(this);
	}

	if (HermesOpenCommand)
	{
		IConsoleManager::Get().UnregisterConsoleObject(HermesOpenCommand);
		HermesOpenCommand = nullptr;
	}

	if (TSharedPtr<SWindow> Window = HermesWindow.Pin())
	{
		Window->RequestDestroyWindow();
	}
	HermesWindow.Reset();

	if (HermesManager.IsValid())
	{
		HermesManager->Shutdown();
		HermesManager.Reset();
	}

	HermesPanel.Reset();
	GSingletonModule = nullptr;

	UE_LOG(LogHermes, Log, TEXT("HermesIntegration module unloaded"));
}

FHermesIntegrationModule& FHermesIntegrationModule::Get()
{
	check(GSingletonModule);
	return *GSingletonModule;
}

void FHermesIntegrationModule::RegisterToolbarButton()
{
	FToolMenuOwnerScoped OwnerScoped(this);

	UToolMenu* Toolbar = UToolMenus::Get()->ExtendMenu("LevelEditor.LevelEditorToolBar.PlayToolBar");
	FToolMenuSection& Section = Toolbar->FindOrAddSection("HermesIntegration");
	FToolMenuEntry Entry = FToolMenuEntry::InitToolBarButton(
		"OpenHermesPanel",
		FToolUIActionChoice(FUIAction(FExecuteAction::CreateRaw(this, &FHermesIntegrationModule::OnToggleHermesPanel))),
		LOCTEXT("HermesButton", "Hermes"),
		LOCTEXT("HermesButtonTooltip", "Open Hermes AI Assistant"),
		FSlateIcon(FAppStyle::GetAppStyleSetName(), "Icons.Activate")
	);
	Entry.StyleNameOverride = "CalloutToolbar";
	Section.AddEntry(Entry);

	UE_LOG(LogHermes, Log, TEXT("Hermes toolbar button registered"));
}

void FHermesIntegrationModule::OnToggleHermesPanel()
{
	if (TSharedPtr<SWindow> ExistingWindow = HermesWindow.Pin())
	{
		ExistingWindow->BringToFront();
		return;
	}

	TSharedRef<SWindow> NewWindow = SNew(SWindow)
		.Title(LOCTEXT("HermesWindowTitle", "Hermes"))
		.ClientSize(FVector2D(800, 600))
		[
			GetOrCreateHermesPanel()
		];
	FSlateApplication::Get().AddWindow(NewWindow);
	HermesWindow = NewWindow;
}

TSharedRef<SHermesPanel> FHermesIntegrationModule::GetOrCreateHermesPanel()
{
	if (!HermesPanel.IsValid())
	{
		HermesPanel = SNew(SHermesPanel)
			.HermesManager(HermesManager);
	}
	return HermesPanel.ToSharedRef();
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FHermesIntegrationModule, HermesIntegration)
