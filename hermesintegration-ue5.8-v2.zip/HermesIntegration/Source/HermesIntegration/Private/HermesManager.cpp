// Copyright (c) 2026 Justin. All Rights Reserved.

#include "HermesManager.h"
#include "HermesIntegration.h"
#include "Sockets.h"
#include "SocketSubsystem.h"
#include "IPAddress.h"
#include "HAL/PlatformMisc.h"
#include "HAL/PlatformProcess.h"
#include "Misc/Paths.h"
#include "Misc/FileHelper.h"

FHermesManager::FHermesManager()
	: bHermesRunning(false)
	, StoredZoomLevel(1.0f)
{
#if PLATFORM_WINDOWS
	HermesExecutablePath = TEXT("hermes");
#elif PLATFORM_LINUX
	HermesExecutablePath = TEXT("hermes");
#elif PLATFORM_MAC
	HermesExecutablePath = TEXT("hermes");
#endif

	// User config directory: ~/.hermes
#if PLATFORM_WINDOWS
	HermesConfigDir = FPaths::Combine(FPlatformProcess::UserHomeDir(), TEXT(".hermes"));
#else
	HermesConfigDir = FPaths::Combine(FPlatformProcess::UserHomeDir(), TEXT(".hermes"));
#endif
}

FHermesManager::~FHermesManager()
{
	StopHermesProcess();
}

void FHermesManager::Initialize()
{
	DetectHermesRunning();
	if (!bHermesRunning)
	{
		EnsureHermesRunning();
	}
}

void FHermesManager::Shutdown()
{
	StopHermesProcess();
}

bool FHermesManager::IsHermesRunning() const
{
	return bHermesRunning;
}

bool FHermesManager::EnsureHermesRunning()
{
	if (IsHermesRunning())
	{
		return true;
	}

	return StartHermesProcess();
}

FString FHermesManager::GetHermesURL() const
{
	return FString::Printf(TEXT("http://127.0.0.1:%d"), GetHermesPort());
}

void FHermesManager::SetZoomLevel(float ZoomLevel)
{
	StoredZoomLevel = FMath::Clamp(ZoomLevel, 0.5f, 2.0f);
}

float FHermesManager::GetZoomLevel() const
{
	return StoredZoomLevel;
}

bool FHermesManager::DetectHermesRunning()
{
	// Check if port 9119 is open
	bHermesRunning = CheckPortAvailable(9119);
	if (bHermesRunning)
	{
		UE_LOG(LogHermes, Log, TEXT("Hermes detected on port 9119"));
	}
	return bHermesRunning;
}

bool FHermesManager::StartHermesProcess()
{
	// The Hermes desktop app exports HERMES_WEB_DIST for its own children. If the
	// editor inherited it (e.g. it was launched from a Hermes session), the spawned
	// server would serve the Electron desktop bundle, which cannot run inside an
	// embedded browser. Clear it so the server serves the standalone web UI.
	FPlatformMisc::SetEnvironmentVar(TEXT("HERMES_WEB_DIST"), TEXT(""));

	// Try to start hermes serve
	FString CommandLine = TEXT("serve --port 9119 --host 127.0.0.1");

#if PLATFORM_WINDOWS
	HermesProcessHandle = FPlatformProcess::CreateProc(*HermesExecutablePath, *CommandLine, true, false, false, nullptr, 0, nullptr, nullptr, nullptr);
#elif PLATFORM_LINUX
	HermesProcessHandle = FPlatformProcess::CreateProc(*HermesExecutablePath, *CommandLine, true, false, false, nullptr, 0, nullptr, nullptr, nullptr);
#elif PLATFORM_MAC
	HermesProcessHandle = FPlatformProcess::CreateProc(*HermesExecutablePath, *CommandLine, true, false, false, nullptr, 0, nullptr, nullptr, nullptr);
#endif

	if (!HermesProcessHandle.IsValid())
	{
		UE_LOG(LogHermes, Log, TEXT("Hermes not launched. Ensure 'hermes' is in PATH and configured with 'hermes setup'"));
		return false;
	}

	// Poll briefly for the server to come up; break out as soon as it binds
	for (int32 Attempt = 0; Attempt < 12; ++Attempt)
	{
		FPlatformProcess::Sleep(0.25f);
		if (CheckPortAvailable(GetHermesPort()))
		{
			bHermesRunning = true;
			UE_LOG(LogHermes, Log, TEXT("Hermes process started successfully"));
			return true;
		}
	}

	// Server not up yet — leave the process running; the panel will connect once it finishes starting
	UE_LOG(LogHermes, Log, TEXT("Hermes is still starting on port %d; the panel will connect once it is ready"), GetHermesPort());
	return false;
}

void FHermesManager::StopHermesProcess()
{
	if (HermesProcessHandle.IsValid())
	{
		FPlatformProcess::TerminateProc(HermesProcessHandle);
		HermesProcessHandle.Reset();
		bHermesRunning = false;
		UE_LOG(LogHermes, Log, TEXT("Hermes process stopped"));
	}
}

bool FHermesManager::CheckPortAvailable(uint16 Port)
{
	ISocketSubsystem* SocketSubsystem = ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM);
	if (!SocketSubsystem)
	{
		return false;
	}

	FSocket* Socket = SocketSubsystem->CreateSocket(NAME_Stream, TEXT("HermesCheck"), true);
	if (!Socket)
	{
		return false;
	}

	TSharedRef<FInternetAddr> RemoteAddr = SocketSubsystem->CreateInternetAddr();
	bool bIsValid = false;
	RemoteAddr->SetIp(TEXT("127.0.0.1"), bIsValid);
	RemoteAddr->SetPort(Port);

	bool bCanConnect = Socket->Connect(*RemoteAddr);
	SocketSubsystem->DestroySocket(Socket);

	return bCanConnect;
}
