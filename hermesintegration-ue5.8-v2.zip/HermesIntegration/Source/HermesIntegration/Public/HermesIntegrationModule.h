// Copyright (c) 2026 Justin. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

class FHermesManager;
class SHermesPanel;
class SWindow;
struct IConsoleCommand;

class FHermesIntegrationModule : public IModuleInterface
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	static FHermesIntegrationModule& Get();

private:
	void RegisterToolbarButton();
	void OnToggleHermesPanel();
	TSharedRef<SHermesPanel> GetOrCreateHermesPanel();

	TSharedPtr<FHermesManager> HermesManager;
	TSharedPtr<SHermesPanel> HermesPanel;
	TWeakPtr<SWindow> HermesWindow;
	IConsoleCommand* HermesOpenCommand = nullptr;
};
