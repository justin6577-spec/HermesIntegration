// Copyright (c) 2026 Justin. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "HAL/PlatformProcess.h"
#include "Containers/List.h"

class FHermesManager : public TSharedFromThis<FHermesManager>
{
public:
	FHermesManager();
	~FHermesManager();

	void Initialize();
	void Shutdown();

	bool IsHermesRunning() const;
	bool EnsureHermesRunning();
	FString GetHermesURL() const;
	uint16 GetHermesPort() const { return 9119; }

	void SetZoomLevel(float ZoomLevel);
	float GetZoomLevel() const;

private:
	bool DetectHermesRunning();
	bool StartHermesProcess();
	void StopHermesProcess();
	bool CheckPortAvailable(uint16 Port);

	FProcHandle HermesProcessHandle;
	bool bHermesRunning;
	float StoredZoomLevel;
	FString HermesExecutablePath;
	FString HermesConfigDir;
};
