// Copyright (c) 2026 Justin. All Rights Reserved.

using UnrealBuildTool;

public class HermesIntegration : ModuleRules
{
	public HermesIntegration(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core"
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"CoreUObject",
			"Engine",
			"Slate",
			"SlateCore",
			"InputCore",
			"UnrealEd",
			"ToolMenus",
			"WebBrowser",
			"Sockets"
		});
	}
}
