// Copyright (c) 2026 Justin. All Rights Reserved.

#include "HermesManager.h"
#include "HermesIntegration.h"
#include "Sockets.h"
#include "SocketSubsystem.h"
#include "IPAddress.h"
#include "HAL/PlatformMisc.h"
#include "HAL/PlatformProcess.h"
#include "Misc/Paths.h"
#include "Misc/FileHelper.h"

FHermesManager::FHermesManager()
    : bHermesRunning(false)
    , StoredZoomLevel(1.0f)
{
#if PLATFORM_WINDOWS
    HermesExecutablePath = TEXT("hermes");
#elif PLATFORM_LINUX
    HermesExecutablePath = TEXT("hermes");
#elif PLATFORM_MAC
    HermesExecutablePath = TEXT("hermes");
#endif

    // User config directory: ~/.hermes
#if PLATFORM_WINDOWS
    HermesConfigDir = FPaths::Combine(FPlatformProcess::UserHomeDir(), TEXT(".hermes"));
#else
    HermesConfigDir = FPaths::Combine(FPlatformProcess::UserHomeDir(), TEXT(".hermes"));
#endif
}

FHermesManager::~FHermesManager()
{
    StopHermesProcess();
}

void FHermesManager::Initialize()
{
    DetectHermesRunning();
    if (!bHermesRunning)
    {
        EnsureHermesRunning();
    }
}

void FHermesManager::Shutdown()
{
    StopHermesProcess();
}

bool FHermesManager::IsHermesRunning() const
{
    return bHermesRunning;
}

bool FHermesManager::EnsureHermesRunning()
{
    if (IsHermesRunning())
    {
        return true;
    }

    return StartHermesProcess();
}

FString FHermesManager::GetHermesURL() const
{
    return FString::Printf(TEXT("http://127.0.0.1:%d"), GetHermesPort());
}

void FHermesManager::SetZoomLevel(float ZoomLevel)
{
    StoredZoomLevel = FMath::Clamp(ZoomLevel, 0.5f, 2.0f);
}

float FHermesManager::GetZoomLevel() const
{
    return StoredZoomLevel;
}

bool FHermesManager::DetectHermesRunning()
{
    // Check if port 9119 is open
    bHermesRunning = CheckPortAvailable(9119);
    if (bHermesRunning)
    {
        UE_LOG(LogHermes, Log, TEXT("Hermes detected on port 9119"));
    }
    return bHermesRunning;
}

bool FHermesManager::StartHermesProcess()
{
	if (HermesProcessHandle.IsValid() && FPlatformProcess::IsProcRunning(HermesProcessHandle))
	{
		return true;
	}

    // The Hermes desktop app exports HERMES_WEB_DIST for its own children. If the
    // editor inherited it (e.g. it was launched from a Hermes session), the spawned
    // server would serve the Electron desktop bundle, which cannot run inside an
    // embedded browser. Clear it so the dashboard builds/serves the standalone web UI.
    FPlatformMisc::SetEnvironmentVar(TEXT("HERMES_WEB_DIST"), TEXT(""));

    // Resolve *how* to launch the dashboard. IMPORTANT: the browser UI is served
    // by `hermes dashboard`, NOT `hermes serve` — `serve` is the headless
    // JSON-RPC/WebSocket backend and returns a 404 at '/', which shows up as a
    // blank panel. `--no-open` stops it spawning an external browser since we
    // embed the page ourselves.
    FString Exe, Args, WorkingDir;
    if (!ResolveHermesLaunch(Exe, Args, WorkingDir))
    {
        UE_LOG(LogHermes, Warning,
            TEXT("Could not locate the Hermes executable. Install Hermes Agent and either add 'hermes' "
                 "to your PATH or use the default install location, then run 'hermes setup'."));
        return false;
    }

    UE_LOG(LogHermes, Log, TEXT("Launching Hermes dashboard: \"%s\" %s"), *Exe, *Args);

    const TCHAR* WorkingDirPtr = WorkingDir.IsEmpty() ? nullptr : *WorkingDir;
    HermesProcessHandle = FPlatformProcess::CreateProc(
        *Exe, *Args,
        /*bLaunchDetached*/ true,
        /*bLaunchHidden*/ true,
        /*bLaunchReallyHidden*/ true,
        nullptr, 0, WorkingDirPtr, nullptr, nullptr);

    if (!HermesProcessHandle.IsValid())
    {
        UE_LOG(LogHermes, Warning,
            TEXT("Failed to launch Hermes (%s). Ensure Hermes Agent is installed and configured with 'hermes setup'."),
            *Exe);
        return false;
    }

    // Do not block the editor thread while the dashboard builds its web UI (the
    // first launch runs a one-time npm build) and binds the port. The panel
    // polls the real port and reloads the view once the UI is actually serving.
    bHermesRunning = true;
    UE_LOG(LogHermes, Log, TEXT("Hermes dashboard launching; waiting for port %d"), GetHermesPort());
    return true;
}

bool FHermesManager::ResolveHermesLaunch(FString& OutExe, FString& OutArgs, FString& OutWorkingDir) const
{
    const FString DashboardArgs =
        FString::Printf(TEXT("dashboard --port %d --host 127.0.0.1 --no-open"), GetHermesPort());

    // 1) A 'hermes' executable on PATH (a normal install that added a shim).
    FString ResolvedPathExe;
    if (FindExecutableInPath(TEXT("hermes"), ResolvedPathExe))
    {
        OutExe = ResolvedPathExe;
        OutArgs = DashboardArgs;
        OutWorkingDir.Reset();
        return true;
    }

#if PLATFORM_WINDOWS
    // 2) Fallback: the standard local install ships a Python launcher (there is
    //    no hermes.exe), so run it with the bundled venv interpreter.
    const FString Home =
        FPaths::Combine(FPlatformProcess::UserHomeDir(), TEXT("AppData/Local/hermes/hermes-agent"));
    const FString VenvPython = FPaths::Combine(Home, TEXT("venv/Scripts/python.exe"));
    const FString Launcher = FPaths::Combine(Home, TEXT("hermes"));
    if (FPaths::FileExists(VenvPython) && FPaths::FileExists(Launcher))
    {
        OutExe = VenvPython;
        OutArgs = FString::Printf(TEXT("\"%s\" %s"), *Launcher, *DashboardArgs);
        OutWorkingDir = Home;
        return true;
    }
#endif

    return false;
}

bool FHermesManager::FindExecutableInPath(const FString& Name, FString& OutFullPath)
{
    const FString PathEnv = FPlatformMisc::GetEnvironmentVariable(TEXT("PATH"));
    if (PathEnv.IsEmpty())
    {
        return false;
    }

    TArray<FString> Dirs;
#if PLATFORM_WINDOWS
    PathEnv.ParseIntoArray(Dirs, TEXT(";"), true);
    const TArray<FString> Exts = { TEXT(".exe"), TEXT(".cmd"), TEXT(".bat"), TEXT("") };
#else
    PathEnv.ParseIntoArray(Dirs, TEXT(":"), true);
    const TArray<FString> Exts = { TEXT("") };
#endif

    for (const FString& Dir : Dirs)
    {
        FString Trimmed = Dir.TrimStartAndEnd().TrimQuotes();
        if (Trimmed.IsEmpty())
        {
            continue;
        }
        for (const FString& Ext : Exts)
        {
            const FString Candidate = FPaths::Combine(Trimmed, Name + Ext);
            if (FPaths::FileExists(Candidate))
            {
                OutFullPath = Candidate;
                return true;
            }
        }
    }
    return false;
}

void FHermesManager::StopHermesProcess()
{
    if (HermesProcessHandle.IsValid())
    {
        FPlatformProcess::TerminateProc(HermesProcessHandle);
        HermesProcessHandle.Reset();
        bHermesRunning = false;
        UE_LOG(LogHermes, Log, TEXT("Hermes process stopped"));
    }
}

bool FHermesManager::CheckPortAvailable(uint16 Port) const
{
    ISocketSubsystem* SocketSubsystem = ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM);
    if (!SocketSubsystem)
    {
        return false;
    }

    FSocket* Socket = SocketSubsystem->CreateSocket(NAME_Stream, TEXT("HermesCheck"), true);
    if (!Socket)
    {
        return false;
    }

    TSharedRef<FInternetAddr> RemoteAddr = SocketSubsystem->CreateInternetAddr();
    bool bIsValid = false;
    RemoteAddr->SetIp(TEXT("127.0.0.1"), bIsValid);
    RemoteAddr->SetPort(Port);

    bool bCanConnect = Socket->Connect(*RemoteAddr);
    SocketSubsystem->DestroySocket(Socket);

    return bCanConnect;
}
