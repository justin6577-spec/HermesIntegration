// Copyright (c) 2026 Justin. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "HAL/PlatformProcess.h"
#include "Containers/List.h"

class FHermesManager : public TSharedFromThis<FHermesManager>
{
public:
	FHermesManager();
	~FHermesManager();

	void Initialize();
	void Shutdown();

	bool IsHermesRunning() const;
	bool EnsureHermesRunning();
	FString GetHermesURL() const;
	uint16 GetHermesPort() const { return 9119; }

	// Fresh, non-cached liveness probe: attempts a loopback TCP connect to the
	// Hermes port right now. Unlike IsHermesRunning() (which returns a cached
	// flag set optimistically the moment the process is spawned), this reflects
	// whether the server has actually finished binding the port, so it is safe
	// to poll from the panel while waiting for `hermes serve` to come up.
	// Thread-safe: creates and destroys its own socket, touches no members.
	bool IsServerResponding() const { return CheckPortAvailable(GetHermesPort()); }

	void SetZoomLevel(float ZoomLevel);
	float GetZoomLevel() const;

private:
	bool DetectHermesRunning();
	bool StartHermesProcess();
	void StopHermesProcess();
	bool CheckPortAvailable(uint16 Port) const;

	// Work out how to launch the Hermes web dashboard. Prefers a 'hermes'
	// executable on PATH; falls back to the bundled Python launcher used by the
	// standard local install (which ships no hermes.exe). Returns false if no
	// launch method could be found.
	bool ResolveHermesLaunch(FString& OutExecutable, FString& OutArguments, FString& OutWorkingDir) const;

	// Search the PATH environment variable for an executable, trying the
	// platform's executable extensions. Returns the resolved absolute path.
	static bool FindExecutableInPath(const FString& Name, FString& OutFullPath);

	FProcHandle HermesProcessHandle;
	bool bHermesRunning;
	float StoredZoomLevel;
	FString HermesExecutablePath;
	FString HermesConfigDir;
};
