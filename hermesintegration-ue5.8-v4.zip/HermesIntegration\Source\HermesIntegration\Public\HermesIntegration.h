// Copyright (c) 2026 Justin. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#define HERMES_PLUGIN_VERSION "1.0.0"

// Logging category
DECLARE_LOG_CATEGORY_EXTERN(LogHermes, Log, All);
