// Copyright (c) 2026 Justin. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"

class FHermesManager;
class SWebBrowser;

class SHermesPanel : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SHermesPanel)
		: _HermesManager(nullptr)
	{
	}
		SLATE_ARGUMENT(TSharedPtr<FHermesManager>, HermesManager)
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

private:
	TSharedPtr<FHermesManager> HermesManager;
	TSharedPtr<SWebBrowser> WebBrowser;
};
