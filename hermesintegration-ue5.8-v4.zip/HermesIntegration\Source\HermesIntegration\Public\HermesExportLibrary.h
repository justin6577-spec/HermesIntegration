// Copyright (c) 2026 Justin. All Rights Reserved.
//
// HermesExportLibrary.h
//
// Blueprint-callable surface for the Hermes asset exporter. The C++ entry
// points live in FHermesAssetExporter; this UBlueprintFunctionLibrary exposes
// them to Editor Utility Blueprints / Blutility so buyers who script the editor
// in Blueprint (not just C++) can drive the exporter from a graph.
//
// Because HermesIntegration is an editor module, these nodes appear in Editor
// Utility Blueprints and Editor Utility Widgets — the correct place to script
// content-pipeline tools — rather than in runtime gameplay Blueprints.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "HermesExportLibrary.generated.h"

UCLASS()
class HERMESINTEGRATION_API UHermesExportLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	/**
	 * Export the given /Game/... asset paths (and, by default, their hard
	 * package dependencies) as .uasset files to a folder on disk. Each path may
	 * be a package path ("/Game/Fab") or an object path ("/Game/Fab/Foo.Foo"),
	 * and is resolved recursively via the Asset Registry.
	 *
	 * @return Number of distinct files written (uasset + sidecar files).
	 */
	UFUNCTION(BlueprintCallable, Category = "Hermes|Export",
		meta = (ToolTip = "Export the given /Game asset paths (plus hard dependencies) as .uasset files to a folder on disk."))
	static int32 ExportAssetsToFolder(
		const TArray<FString>& AssetPaths,
		const FString& TargetDirectory,
		bool bIncludeDependencies = true);

	/**
	 * Export whatever is currently selected in the Content Browser to a folder
	 * on disk. No folder-picker dialog — the caller supplies the destination,
	 * which makes this safe to call from an automated editor script.
	 *
	 * @return Number of distinct files written, or 0 if nothing is selected.
	 */
	UFUNCTION(BlueprintCallable, Category = "Hermes|Export",
		meta = (ToolTip = "Export the current Content Browser selection (plus hard dependencies) to a folder on disk."))
	static int32 ExportSelectedAssetsToFolder(
		const FString& TargetDirectory,
		bool bIncludeDependencies = true);
};
