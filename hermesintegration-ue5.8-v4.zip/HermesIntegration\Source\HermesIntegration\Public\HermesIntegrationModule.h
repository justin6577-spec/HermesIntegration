// Copyright (c) 2026 Justin. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

class FHermesManager;
class SHermesPanel;
class SWindow;
struct IConsoleCommand;

class FHermesIntegrationModule : public IModuleInterface
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	static FHermesIntegrationModule& Get();

	// Toggle the Hermes panel window. Exposed as public so the free function
	// wrapper used by the Tools menu can call it; the wrapper is necessary
	// because FExecuteAction needs a free static function for binding.
	void OnToggleHermesPanel();

private:
	void RegisterToolbarButton();
	void RegisterToolsMenu();
	TSharedRef<SHermesPanel> GetOrCreateHermesPanel();

	TSharedPtr<FHermesManager> HermesManager;
	TSharedPtr<SHermesPanel> HermesPanel;
	TWeakPtr<SWindow> HermesWindow;
	IConsoleCommand* HermesOpenCommand = nullptr;
	IConsoleCommand* HermesExportCommand = nullptr;
	IConsoleCommand* HermesHeadlessExportCommand = nullptr;
};
