// Copyright (c) 2026 Justin. All Rights Reserved.

#include "HermesIntegrationModule.h"
#include "HermesAssetExporter.h"
#include "HermesManager.h"
#include "HermesPanel.h"
#include "HermesIntegration.h"
#include "Framework/Application/SlateApplication.h"
#include "HAL/IConsoleManager.h"
#include "Styling/AppStyle.h"
#include "ToolMenus.h"
#include "Widgets/SWindow.h"

#define LOCTEXT_NAMESPACE "FHermesIntegrationModule"

DEFINE_LOG_CATEGORY(LogHermes);

static FHermesIntegrationModule* GSingletonModule = nullptr;

class FHermesIntegrationModule;
static void OnToggleHermesPanelStaticStub();

void FHermesIntegrationModule::StartupModule()
{
	GSingletonModule = this;

	HermesManager = MakeShared<FHermesManager>();
	HermesManager->Initialize();

	// Register toolbar button once the ToolMenus system is ready
	UToolMenus::RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FHermesIntegrationModule::RegisterToolbarButton));

	// Register Tools menu entry (extending the main editor menu, not just
	// the toolbar) so users can find the export command even if they don't
	// have the toolbar visible.
	UToolMenus::RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FHermesIntegrationModule::RegisterToolsMenu));

	// Register console commands as fallback
	HermesOpenCommand = IConsoleManager::Get().RegisterConsoleCommand(
		TEXT("Hermes.Open"),
		TEXT("Open the Hermes AI Assistant panel"),
		FConsoleCommandDelegate::CreateRaw(this, &FHermesIntegrationModule::OnToggleHermesPanel),
		ECVF_Default
	);

	HermesExportCommand = IConsoleManager::Get().RegisterConsoleCommand(
		TEXT("Hermes.ExportSelected"),
		TEXT("Export the current Content Browser selection as .uasset files to a chosen folder. "
		     "Resolves hard package dependencies. This is the same export action available under "
		     "Tools > Hermes > Export Selected Assets."),
		FConsoleCommandDelegate::CreateStatic(&FHermesAssetExporter::PromptAndExportSelectionVoid),
		ECVF_Default
	);

	// Headless export entry point: Hermes.Export <TargetDir> <AssetPath1> [AssetPath2 ...]
	HermesHeadlessExportCommand = IConsoleManager::Get().RegisterConsoleCommand(
		TEXT("Hermes.Export"),
		TEXT("Headless .uasset export. Usage: Hermes.Export <TargetDir> <AssetPath1> [AssetPath2 ...]. "
		     "Resolves each /Game/... path recursively via the Asset Registry and copies the packages "
		     "plus hard dependencies to <TargetDir>. No UI required — safe for automation."),
		FConsoleCommandWithArgsDelegate::CreateStatic(&FHermesAssetExporter::ExportConsoleCommand),
		ECVF_Default
	);

	UE_LOG(LogHermes, Log, TEXT("HermesIntegration module loaded - use 'Hermes.Open' or 'Hermes.ExportSelected' console commands"));
}

void FHermesIntegrationModule::ShutdownModule()
{
	UToolMenus::UnRegisterStartupCallback(this);
	if (UToolMenus* ToolMenus = UToolMenus::TryGet())
	{
		ToolMenus->UnregisterOwner(this);
	}

	if (HermesOpenCommand)
	{
		IConsoleManager::Get().UnregisterConsoleObject(HermesOpenCommand);
		HermesOpenCommand = nullptr;
	}

	if (HermesExportCommand)
	{
		IConsoleManager::Get().UnregisterConsoleObject(HermesExportCommand);
		HermesExportCommand = nullptr;
	}

	if (HermesHeadlessExportCommand)
	{
		IConsoleManager::Get().UnregisterConsoleObject(HermesHeadlessExportCommand);
		HermesHeadlessExportCommand = nullptr;
	}

	if (TSharedPtr<SWindow> Window = HermesWindow.Pin())
	{
		Window->RequestDestroyWindow();
	}
	HermesWindow.Reset();

	if (HermesManager.IsValid())
	{
		HermesManager->Shutdown();
		HermesManager.Reset();
	}

	HermesPanel.Reset();
	GSingletonModule = nullptr;

	UE_LOG(LogHermes, Log, TEXT("HermesIntegration module unloaded"));
}

FHermesIntegrationModule& FHermesIntegrationModule::Get()
{
	check(GSingletonModule);
	return *GSingletonModule;
}

void FHermesIntegrationModule::RegisterToolsMenu()
{
	// Extend the editor's main "Tools" menu with a submenu so the export
	// action is discoverable without needing the toolbar visible.
	FToolMenuOwnerScoped OwnerScoped(this);

	UToolMenu* ToolsMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.MainMenu.Tools");
	if (!ToolsMenu)
	{
		// Fallback: try the older menu path used in some UE 5.8 builds.
		ToolsMenu = UToolMenus::Get()->ExtendMenu("MainFrame.MainMenu.Tools");
	}
	if (!ToolsMenu)
	{
		UE_LOG(LogHermes, Warning, TEXT("Could not extend the Tools menu — Hermes export submenu not added"));
		return;
	}

	FToolMenuSection& Section = ToolsMenu->FindOrAddSection("HermesIntegration");

	Section.AddSubMenu(
		"HermesMenu",
		LOCTEXT("HermesMenuLabel", "Hermes"),
		LOCTEXT("HermesMenuTooltip", "Hermes AI assistant and asset tools"),
		FNewToolMenuDelegate::CreateLambda([](UToolMenu* SubMenu)
		{
			FToolMenuSection& SubSection = SubMenu->FindOrAddSection("Actions");
			SubSection.AddMenuEntry(
				"OpenHermesPanel",
				TAttribute<FText>(LOCTEXT("OpenHermesPanel", "Open Hermes Panel")),
				TAttribute<FText>(LOCTEXT("OpenHermesPanelTooltip", "Open the embedded Hermes AI assistant panel")),
				TAttribute<FSlateIcon>(FSlateIcon(FAppStyle::GetAppStyleSetName(), "Icons.Activate")),
				FToolUIActionChoice(FUIAction(FExecuteAction::CreateStatic(&OnToggleHermesPanelStaticStub)))
			);
			SubSection.AddMenuEntry(
				"ExportSelectedAssets",
				TAttribute<FText>(LOCTEXT("ExportSelectedAssets", "Export Selected Assets...")),
				TAttribute<FText>(LOCTEXT("ExportSelectedAssetsTooltip", "Copy the Content Browser selection and its hard dependencies as .uasset files to a chosen folder")),
				TAttribute<FSlateIcon>(FSlateIcon(FAppStyle::GetAppStyleSetName(), "Icons.Save")),
				FToolUIActionChoice(FUIAction(FExecuteAction::CreateStatic(&FHermesAssetExporter::PromptAndExportSelectionVoid)))
			);
		})
	);

	UE_LOG(LogHermes, Log, TEXT("Hermes Tools menu registered"));
}

void OnToggleHermesPanelStaticStub()
{
	if (FHermesIntegrationModule* Module = GSingletonModule)
	{
		Module->OnToggleHermesPanel();
	}
}

void FHermesIntegrationModule::RegisterToolbarButton()
{
	FToolMenuOwnerScoped OwnerScoped(this);

	UToolMenu* Toolbar = UToolMenus::Get()->ExtendMenu("LevelEditor.LevelEditorToolBar.PlayToolBar");
	FToolMenuSection& Section = Toolbar->FindOrAddSection("HermesIntegration");
	FToolMenuEntry Entry = FToolMenuEntry::InitToolBarButton(
		"OpenHermesPanel",
		FToolUIActionChoice(FUIAction(FExecuteAction::CreateRaw(this, &FHermesIntegrationModule::OnToggleHermesPanel))),
		LOCTEXT("HermesButton", "Hermes"),
		LOCTEXT("HermesButtonTooltip", "Open Hermes AI Assistant"),
		FSlateIcon(FAppStyle::GetAppStyleSetName(), "Icons.Activate")
	);
	Entry.StyleNameOverride = "CalloutToolbar";
	Section.AddEntry(Entry);

	UE_LOG(LogHermes, Log, TEXT("Hermes toolbar button registered"));
}

void FHermesIntegrationModule::OnToggleHermesPanel()
{
	if (TSharedPtr<SWindow> ExistingWindow = HermesWindow.Pin())
	{
		ExistingWindow->BringToFront();
		return;
	}

	TSharedRef<SWindow> NewWindow = SNew(SWindow)
		.Title(LOCTEXT("HermesWindowTitle", "Hermes"))
		.ClientSize(FVector2D(800, 600))
		[
			GetOrCreateHermesPanel()
		];
	FSlateApplication::Get().AddWindow(NewWindow);
	HermesWindow = NewWindow;
}

TSharedRef<SHermesPanel> FHermesIntegrationModule::GetOrCreateHermesPanel()
{
	if (!HermesPanel.IsValid())
	{
		HermesPanel = SNew(SHermesPanel)
			.HermesManager(HermesManager);
	}
	return HermesPanel.ToSharedRef();
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FHermesIntegrationModule, HermesIntegration)
