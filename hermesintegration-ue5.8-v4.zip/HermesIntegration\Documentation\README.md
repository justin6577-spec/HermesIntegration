# Hermes Integration

Embed Nous Research's Hermes Agent web UI directly in the Unreal Editor. Access your local Hermes AI assistant without leaving Unreal Engine.

## Features

- **Embedded Web UI** — the full Hermes web interface runs inside a floating editor window
- **Auto-Detection** — detects an existing Hermes server on port 9119
- **Auto-Launch** — starts `hermes dashboard` automatically if no server is running (uses `hermes` from your PATH, or the default local install)
- **Toolbar Button & Console Command** — open the panel from the Level Editor toolbar or with `Hermes.Open`
- **Cross-Platform** — Windows, Linux, and macOS, rendered via the engine's Chromium Embedded Framework (CEF)

## Requirements

- Unreal Engine 5.8
- [Hermes Agent](https://hermes-agent.nousresearch.com/) installed and configured on your machine

## Installation

1. **Install Hermes Agent** (if you haven't already):
   - Follow the instructions at https://hermes-agent.nousresearch.com/
   - Run `hermes setup` once to configure providers and API keys
2. **Install the plugin**:
   - From Fab: add the plugin to your engine via the Epic Games Launcher, or
   - Manually: copy the `HermesIntegration` folder into your project's `Plugins/` directory
3. **Enable it** in the editor under **Edit → Plugins → Editor**, then restart the editor.

## Usage

1. **Open the panel** — click the **Hermes** button in the Level Editor toolbar (next to the Play controls), or run the `Hermes.Open` console command (see `CONSOLE_COMMAND.md`).
2. **Interact** — use the embedded Hermes web UI exactly like the standalone version.
3. **Close / reopen** — close the window normally; opening again brings the existing window to the front instead of creating a duplicate.

## How It Works

- On editor startup the plugin checks for a Hermes server on `127.0.0.1:9119`; if none is found it launches `hermes dashboard --port 9119 --host 127.0.0.1 --no-open` (the dashboard serves the browser UI; `hermes serve` is the headless backend and intentionally serves no web page).
- The embedded browser (CEF) displays the Hermes web interface in a floating 800x600 window.
- All of your existing Hermes configuration (`~/.hermes/`) is reused — the plugin stores no credentials of its own.

## Troubleshooting

### Hermes fails to start
- Ensure `hermes` is installed and in your system PATH (`which hermes` / `where hermes`).
- Run `hermes setup` from a shell to configure providers.

### Window opens but the page is blank
- Verify the server is reachable: `curl http://127.0.0.1:9119`
- Start it manually if needed: `hermes dashboard --port 9119 --host 127.0.0.1 --no-open`

### Plugin fails to load
- Confirm you are on Unreal Engine 5.8.
- Check the Output Log (**Window → Output Log**) for lines from the `LogHermes` category.

## Architecture

```
HermesIntegration/
├── Config/FilterPlugin.ini
├── Documentation/                    (this folder)
├── Resources/Icon128.png
├── Source/HermesIntegration/
│   ├── Public/
│   │   ├── HermesIntegration.h       (log category, plugin version)
│   │   ├── HermesIntegrationModule.h (editor module, toolbar & console command)
│   │   ├── HermesManager.h           (Hermes process/server management)
│   │   └── HermesPanel.h             (Slate widget hosting the web view)
│   └── Private/
│       ├── HermesIntegrationModule.cpp
│       ├── HermesManager.cpp
│       └── HermesPanel.cpp
└── HermesIntegration.uplugin
```

## License

This plugin integrates with Nous Research's Hermes Agent, which is installed and licensed separately. Refer to Hermes Agent's own licensing for details.
