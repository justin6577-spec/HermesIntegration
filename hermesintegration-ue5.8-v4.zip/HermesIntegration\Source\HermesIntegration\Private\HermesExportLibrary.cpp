// Copyright (c) 2026 Justin. All Rights Reserved.
//
// HermesExportLibrary.cpp — see HermesExportLibrary.h.

#include "HermesExportLibrary.h"
#include "HermesAssetExporter.h"

#include "AssetRegistry/AssetData.h"
#include "ContentBrowserModule.h"
#include "IContentBrowserSingleton.h"
#include "Modules/ModuleManager.h"

int32 UHermesExportLibrary::ExportAssetsToFolder(
	const TArray<FString>& AssetPaths,
	const FString& TargetDirectory,
	bool bIncludeDependencies)
{
	return FHermesAssetExporter::HeadlessExport(AssetPaths, TargetDirectory, bIncludeDependencies);
}

int32 UHermesExportLibrary::ExportSelectedAssetsToFolder(
	const FString& TargetDirectory,
	bool bIncludeDependencies)
{
	FContentBrowserModule& ContentBrowserModule =
		FModuleManager::LoadModuleChecked<FContentBrowserModule>(TEXT("ContentBrowser"));

	TArray<FAssetData> SelectedAssets;
	ContentBrowserModule.Get().GetSelectedAssets(SelectedAssets);

	return FHermesAssetExporter::ExportSelectedAssets(SelectedAssets, TargetDirectory, bIncludeDependencies);
}
