# Building & Packaging — UE 5.4 to 5.8

Hermes Integration is source-compatible across **Unreal Engine 5.4, 5.5, 5.6,
5.7, and 5.8**. Fab distributes code plugins as one compiled build *per engine
version*, so this folder ships a script that produces all of them.

## One-command packaging

From this plugin's `Scripts/` folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\package_all_versions.ps1
```

For each engine version that is installed under `C:\Program Files\Epic Games\`,
the script:

1. Stages a clean copy of the plugin (no `Binaries/`, `Intermediate/`, `Dist/`,
   `Saved/`, or `Scripts/`).
2. Stamps the staged `.uplugin`'s `EngineVersion` to that engine (e.g. `5.6.0`).
3. Runs `RunUAT BuildPlugin` to compile and package it.
4. Zips the result to `Dist\HermesIntegration_UE_<ver>.zip` — ready to upload.

Versions that are **not installed are skipped** (with a notice), so you can run
the same command on any machine and it packages whatever engines it finds.
A run-summary table is printed at the end.

### Options

```powershell
# Only specific versions
.\package_all_versions.ps1 -Versions 5.7,5.8

# Engines installed on another drive/root
.\package_all_versions.ps1 -EpicRoot "D:\Epic"
```

## Requirements per version

To build for a given version you need **that engine installed** with its C++
toolchain (Visual Studio 2022 + the matching Windows SDK). The script cannot
compile 5.6 without UE 5.6 present — install the versions you intend to ship, or
let Fab's build service compile from the submitted source.

## Compatibility notes

The plugin deliberately avoids any API introduced after 5.4:

| Area | API used | Available since |
|------|----------|-----------------|
| Asset export | `IAssetRegistry::GetAssetByObjectPath(const FSoftObjectPath&)` | 5.1 |
| Package resolve | `FPackageName::DoesPackageExist(const FString&, FString*)` | 5.0 |
| Path convert | `FPackageName::TryConvertLongPackageNameToFilename(FString, …)` | 5.0 |
| Menus/toolbar | `UToolMenus` extensions | 5.0 |
| Web UI | `SWebBrowser` (`WebBrowser` module) | 4.x |
| Styling | `FAppStyle::GetAppStyleSetName()` | 5.0 |
| Async reload | `Async` / `AsyncTask(ENamedThreads::GameThread, …)` | 4.x |
| Blueprint API | `UBlueprintFunctionLibrary` | 4.x |

If a future engine deprecates one of these, guard the call with
`ENGINE_MAJOR_VERSION` / `ENGINE_MINOR_VERSION` from `Runtime/Launch/Resources/Version.h`
rather than forking the source.

## Manual single-version build

To build against one engine without the script:

```powershell
& "C:\Program Files\Epic Games\UE_5.8\Engine\Build\BatchFiles\RunUAT.bat" `
    BuildPlugin `
    -Plugin="<path>\HermesIntegration.uplugin" `
    -Package="<out>\UE_5.8" `
    -Rocket -TargetPlatforms=Win64
```

> Close the Unreal Editor first — an open editor with **Live Coding** active
> holds a build lock and will cause `BuildPlugin` to fail.
