// Copyright (c) 2026 Justin. All Rights Reserved.

#include "HermesPanel.h"
#include "HermesManager.h"
#include "Widgets/Layout/SBorder.h"
#include "SWebBrowser.h"
#include "Styling/AppStyle.h"
#include "Async/Async.h"

void SHermesPanel::Construct(const FArguments& InArgs)
{
	HermesManager = InArgs._HermesManager;

	FString URL = TEXT("about:blank");
	if (HermesManager.IsValid())
	{
		URL = HermesManager->GetHermesURL();
	}

	ChildSlot
	[
		SNew(SBorder)
		.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
		.Padding(2.0f)
		[
			SAssignNew(WebBrowser, SWebBrowser)
			.InitialURL(URL)
			.ShowControls(true)
			.ShowAddressBar(false)
			.SupportsTransparency(false)
		]
	];

	// The Hermes server may not have finished binding its port when the web view
	// is first constructed above (the manager launches `hermes serve`
	// asynchronously and reports "running" optimistically). If we do nothing,
	// the browser loads before the server answers and the user sees a blank
	// page until they manually reload. So, unless the server already responds,
	// poll the real port on a background thread and reload the web view on the
	// game thread the moment it comes up.
	const bool bReadyNow = HermesManager.IsValid() && HermesManager->IsServerResponding();
	if (HermesManager.IsValid() && !bReadyNow && URL != TEXT("about:blank"))
	{
		TWeakPtr<FHermesManager> WeakManager = HermesManager;
		TWeakPtr<SWebBrowser> WeakBrowser = WebBrowser;
		Async(EAsyncExecution::ThreadPool, [WeakManager, WeakBrowser, URL]()
		{
			// ~150s budget: the dashboard's *first* launch runs a one-time npm
			// build of the web UI before it binds the port, which can take a
			// minute or more; subsequent launches are near-instant.
			constexpr int32 MaxAttempts = 300;
			for (int32 Attempt = 0; Attempt < MaxAttempts; ++Attempt)
			{
				TSharedPtr<FHermesManager> Manager = WeakManager.Pin();
				if (!Manager.IsValid())
				{
					return; // panel/manager torn down while waiting
				}
				if (Manager->IsServerResponding())
				{
					// Slate widgets must only be touched on the game thread.
					AsyncTask(ENamedThreads::GameThread, [WeakBrowser, URL]()
					{
						if (TSharedPtr<SWebBrowser> Browser = WeakBrowser.Pin())
						{
							Browser->LoadURL(URL);
						}
					});
					return;
				}
				FPlatformProcess::Sleep(0.5f);
			}

			// Timed out — replace the blank view with an actionable message
			// rather than leaving the user staring at an empty window.
			AsyncTask(ENamedThreads::GameThread, [WeakBrowser, URL]()
			{
				if (TSharedPtr<SWebBrowser> Browser = WeakBrowser.Pin())
				{
					const FString Html = FString::Printf(TEXT(
						"<html><body style='font-family:Segoe UI,Arial,sans-serif;background:#1b1d23;"
						"color:#d7dbe0;padding:32px;line-height:1.6'>"
						"<h2 style='color:#fff'>Hermes isn&#39;t responding yet</h2>"
						"<p>The Hermes dashboard did not start on <code>%s</code> within the timeout.</p>"
						"<ul>"
						"<li>Make sure <b>Hermes Agent</b> is installed and you have run <code>hermes setup</code>.</li>"
						"<li>Start it manually: <code>hermes dashboard --port 9119 --host 127.0.0.1 --no-open</code></li>"
						"<li>The first launch builds the web UI once and can take a minute.</li>"
						"</ul>"
						"<p style='color:#8a93a0'>Close and reopen this panel to retry.</p>"
						"</body></html>"), *URL);
					Browser->LoadString(Html, URL);
				}
			});
		});
	}
}
