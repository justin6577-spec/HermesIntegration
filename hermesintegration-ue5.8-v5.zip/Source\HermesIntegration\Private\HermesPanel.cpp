// Copyright (c) 2026 Justin. All Rights Reserved.

#include "HermesPanel.h"
#include "HermesManager.h"
#include "Widgets/Layout/SBorder.h"
#include "SWebBrowser.h"
#include "Styling/AppStyle.h"
#include "Async/Async.h"

void SHermesPanel::Construct(const FArguments& InArgs)
{
	HermesManager = InArgs._HermesManager;

	ChildSlot
	[
		SNew(SBorder)
		.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
		.Padding(2.0f)
		[
			SAssignNew(WebBrowser, SWebBrowser)
			.InitialURL(TEXT("about:blank"))
			.ShowControls(true)
			.ShowAddressBar(false)
			.SupportsTransparency(false)
		]
	];

	// Start with about:blank so CEF never shows a "failed to load" error page.
	// Once the Hermes server actually responds, load the real URL.
	if (HermesManager.IsValid() && HermesManager->IsHermesURL())
	{
		FString URL = HermesManager->GetHermesURL();
		const bool bReadyNow = HermesManager->IsServerResponding();

		if (bReadyNow)
		{
			WebBrowser->LoadURL(URL);
		}
		else
		{
			TWeakPtr<FHermesManager> WeakManager = HermesManager;
			TWeakPtr<SWebBrowser> WeakBrowser = WebBrowser;
			Async(EAsyncExecution::ThreadPool, [WeakManager, WeakBrowser, URL]()
			{
				for (int32 Attempt = 0; Attempt < 60; ++Attempt)
				{
					TSharedPtr<FHermesManager> Manager = WeakManager.Pin();
					if (!Manager.IsValid()) return;
					if (Manager->IsServerResponding())
					{
						AsyncTask(ENamedThreads::GameThread, [WeakBrowser, URL]()
						{
							if (TSharedPtr<SWebBrowser> Browser = WeakBrowser.Pin())
							{
								Browser->LoadURL(URL);
							}
						});
						return;
					}
					FPlatformProcess::Sleep(0.5f);
				}
			});
		}
	}
}
