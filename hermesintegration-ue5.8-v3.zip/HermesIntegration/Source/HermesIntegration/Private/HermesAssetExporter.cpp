// Copyright (c) 2026 Justin. All Rights Reserved.
//
// HermesAssetExporter.cpp
//
// Implementation of the .uasset export feature. See HermesAssetExporter.h for
// the public contract and the rationale (Fab "exporting Unreal Engine files"
// warning).

#include "HermesAssetExporter.h"
#include "HermesIntegration.h"

#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetRegistry/IAssetRegistry.h"
#include "ContentBrowserModule.h"
#include "DesktopPlatformModule.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Notifications/NotificationManager.h"
#include "GenericPlatform/GenericWindow.h"
#include "IContentBrowserSingleton.h"
#include "IDesktopPlatform.h"
#include "Misc/FileHelper.h"
#include "Misc/PackageName.h"
#include "Misc/Paths.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "Widgets/SWindow.h"

DEFINE_LOG_CATEGORY_STATIC(LogHermesExporter, Log, All);

namespace HermesAssetExporter
{
	// Each Unreal package on disk can be accompanied by sidecar files (e.g. the
	// .uexp and .ubulk that bulk data and external packages get split into).
	// Copying the bare .uasset is not enough — assets that reference bulk data
	// will fail to load in the receiving project without the sidecars.
	static const TArray<FString>& GetPackageFileExtensions()
	{
		static const TArray<FString> Extensions = {
			TEXT(".uasset"),
			TEXT(".umap"),
			TEXT(".uexp"),
			TEXT(".ubulk"),
			TEXT(".uptnl"),
		};
		return Extensions;
	}

	// Case-insensitive StartsWith helper — UE 5.8 uses ESearchCase::IgnoreCase,
	// not ESearchCase::CaseIgnoreSearch. Declared above all callers so the
	// compiler can find it during name lookup.
	static bool StartsWithIgnoreCase(const FString& Haystack, const FString& Needle)
	{
		return Haystack.StartsWith(Needle, ESearchCase::IgnoreCase);
	}

	/**
	 * Given a long package name like /Game/Foo/Bar, return the absolute
	 * filename of the package file (e.g. .../Content/Foo/Bar.uasset) and
	 * confirm the file actually exists on disk.
	 */
	static bool TryResolvePackageFile(const FName PackageName, FString& OutPackageFilename)
	{
		const FString LongPackageName = PackageName.ToString();
		if (!FPackageName::TryConvertLongPackageNameToFilename(LongPackageName, OutPackageFilename, FPackageName::GetAssetPackageExtension()))
		{
			return false;
		}
		return FPaths::FileExists(OutPackageFilename);
	}

	/**
	 * For a given source package file, compute the relative path under the
	 * project's Content directory so the export preserves the same layout.
	 *
	 * Example: .../Content/UI/HUD/HealthBar.uasset -> UI/HUD/HealthBar.uasset
	 */
	static FString GetRelativePathUnderContent(const FString& AbsoluteFilename)
	{
		FString ContentDir;
		if (FPaths::IsRelative(AbsoluteFilename))
		{
			return FPaths::GetCleanFilename(AbsoluteFilename);
		}

		// Project-relative content path. The package filename was built from
		// /Game/... which on disk maps to <ProjectRoot>/Content/...
		FString ProjectContentDir;
		// Wrap the long package name in FString to disambiguate from the
		// FStringView overload of TryConvertLongPackageNameToFilename.
		if (FPackageName::TryConvertLongPackageNameToFilename(FString(TEXT("/Game")), ProjectContentDir))
		{
			FString ProjectContentDirAbs = FPaths::ConvertRelativePathToFull(ProjectContentDir);
			FString Abs = FPaths::ConvertRelativePathToFull(AbsoluteFilename);
			if (StartsWithIgnoreCase(Abs, ProjectContentDirAbs))
			{
				FString Relative = Abs.RightChop(ProjectContentDirAbs.Len());
				Relative.RemoveFromStart(TEXT("/"));
				Relative.RemoveFromStart(TEXT("\\"));
				return Relative;
			}
		}

		// Plugins or other content roots — fall back to just the filename so
		// we still produce a usable export.
		return FPaths::GetCleanFilename(AbsoluteFilename);
	}

	/**
	 * Build the set of all long package names we need to copy, given the
	 * user's starting selection and the dependency-include flag.
	 */
	static void GatherPackageClosure(
		const TArray<FAssetData>& SelectedAssets,
		bool bIncludeDependencies,
		TSet<FName>& OutPackageNames)
	{
		FAssetRegistryModule& AssetRegistryModule =
			FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
		IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();

		TArray<FName> InitialPackages;
		InitialPackages.Reserve(SelectedAssets.Num());
		for (const FAssetData& Asset : SelectedAssets)
		{
			if (Asset.PackageName.IsNone())
			{
				continue;
			}
			InitialPackages.AddUnique(Asset.PackageName);
		}

		OutPackageNames.Reserve(InitialPackages.Num() * 2);
		for (const FName& PackageName : InitialPackages)
		{
			OutPackageNames.Add(PackageName);
		}

		if (!bIncludeDependencies)
		{
			return;
		}

		// BFS through hard package dependencies.
		TArray<FName> Frontier = InitialPackages;
		constexpr int32 MaxDepth = 8; // safety bound — prevents runaway traversal
		for (int32 Depth = 0; Depth < MaxDepth && Frontier.Num() > 0; ++Depth)
		{
			TArray<FName> NextFrontier;
			NextFrontier.Reserve(Frontier.Num() * 4);

			for (const FName& PackageName : Frontier)
			{
				TArray<FName> Deps;
				// FDependencyQuery has a constructor that takes EDependencyQuery
				// flags. Hard = required-load refs; we don't set Game/Build so we
				// match both editor and game deps. Soft refs are excluded, which
				// matches what "this asset depends on to load" means in practice.
				const UE::AssetRegistry::FDependencyQuery DepQuery(
					UE::AssetRegistry::EDependencyQuery::Hard);

				AssetRegistry.GetDependencies(
					PackageName,
					Deps,
					UE::AssetRegistry::EDependencyCategory::Package,
					DepQuery);

				for (const FName& Dep : Deps)
				{
					if (Dep.IsNone() || OutPackageNames.Contains(Dep) || NextFrontier.Contains(Dep))
					{
						continue;
					}
					// Skip engine / script / developer content — we only want
					// project / plugin user content in the export.
					const FString DepStr = Dep.ToString();
					if (DepStr.StartsWith(TEXT("/Engine/")) ||
						DepStr.StartsWith(TEXT("/Script/")))
					{
						continue;
					}
					NextFrontier.Add(Dep);
					OutPackageNames.Add(Dep);
				}
			}

			Frontier = MoveTemp(NextFrontier);
		}
	}

	/**
	 * Show a transient editor notification summarizing the result.
	 */
	static void ShowCompletionNotification(int32 FilesWritten, int32 PackagesCopied, const FString& TargetDirectory, bool bSuccess)
	{
		FNotificationInfo Info(bSuccess
			? FText::Format(
				NSLOCTEXT("HermesAssetExporter", "ExportSuccess", "Exported {0} packages ({1} files) to {2}"),
				FText::AsNumber(PackagesCopied),
				FText::AsNumber(FilesWritten),
				FText::FromString(TargetDirectory))
			: NSLOCTEXT("HermesAssetExporter", "ExportFailed", "Hermes export failed — see Output Log"));

		Info.ExpireDuration = 6.0f;
		Info.bUseSuccessFailIcons = true;

		FSlateNotificationManager::Get().AddNotification(Info)
			->SetCompletionState(bSuccess ? SNotificationItem::CS_Success : SNotificationItem::CS_Fail);
	}
}

int32 FHermesAssetExporter::ExportSelectedAssets(
	const TArray<FAssetData>& SelectedAssets,
	const FString& TargetDirectory,
	bool bIncludeDependencies)
{
	using namespace HermesAssetExporter;

	if (SelectedAssets.Num() == 0)
	{
		UE_LOG(LogHermesExporter, Warning, TEXT("ExportSelectedAssets: empty selection — nothing to do"));
		return 0;
	}

	if (TargetDirectory.IsEmpty())
	{
		UE_LOG(LogHermesExporter, Error, TEXT("ExportSelectedAssets: target directory is empty"));
		return 0;
	}

	// Ensure the destination folder exists. UE editor UI is on the main
	// thread; file IO below is small (selection-level, not whole-content).
	IFileManager::Get().MakeDirectory(*TargetDirectory, /*Tree*/ true);

	TSet<FName> PackageClosure;
	GatherPackageClosure(SelectedAssets, bIncludeDependencies, PackageClosure);

	UE_LOG(LogHermesExporter, Log,
		TEXT("Exporting %d selected assets + %d dependencies to %s"),
		SelectedAssets.Num(), PackageClosure.Num() - SelectedAssets.Num(), *TargetDirectory);

	int32 FilesWritten = 0;
	int32 PackagesCopied = 0;
	int32 PackagesSkipped = 0;

	for (const FName& PackageName : PackageClosure)
	{
		FString SourceFilename;
		if (!TryResolvePackageFile(PackageName, SourceFilename))
		{
			UE_LOG(LogHermesExporter, Warning, TEXT("Skipping %s — could not resolve on-disk filename"), *PackageName.ToString());
			++PackagesSkipped;
			continue;
		}

		const FString RelativePath = GetRelativePathUnderContent(SourceFilename);
		const FString BaseRelative = FPaths::GetPath(RelativePath);
		const FString FileName = FPaths::GetCleanFilename(RelativePath);
		const FString DestDir = FPaths::Combine(TargetDirectory, BaseRelative);
		IFileManager::Get().MakeDirectory(*DestDir, /*Tree*/ true);

		// Copy the main package file.
		const FString DestPackage = FPaths::Combine(DestDir, FileName);
		if (IFileManager::Get().Copy(*DestPackage, *SourceFilename) != COPY_OK)
		{
			UE_LOG(LogHermesExporter, Error, TEXT("Failed to copy %s -> %s"), *SourceFilename, *DestPackage);
			++PackagesSkipped;
			continue;
		}
		++FilesWritten;
		++PackagesCopied;

		// Copy sidecar files (.uexp, .ubulk, .uptnl) that share the package
		// basename. The engine emits these alongside .uasset when an asset has
		// bulk data or external objects.
		const FString BasePath = FPaths::Combine(FPaths::GetPath(SourceFilename), FPaths::GetBaseFilename(SourceFilename));
		for (const FString& Ext : GetPackageFileExtensions())
		{
			if (Ext.Equals(FPackageName::GetAssetPackageExtension(), ESearchCase::IgnoreCase))
			{
				continue; // already copied above
			}
			const FString SidecarSrc = BasePath + Ext;
			if (FPaths::FileExists(SidecarSrc))
			{
				const FString SidecarDst = FPaths::Combine(DestDir, FPaths::GetCleanFilename(SidecarSrc));
				if (IFileManager::Get().Copy(*SidecarDst, *SidecarSrc) == COPY_OK)
				{
					++FilesWritten;
				}
			}
		}
	}

	UE_LOG(LogHermesExporter, Log,
		TEXT("Export complete: %d packages, %d files written, %d skipped"),
		PackagesCopied, FilesWritten, PackagesSkipped);

	ShowCompletionNotification(FilesWritten, PackagesCopied, TargetDirectory, /*bSuccess*/ PackagesCopied > 0);
	return FilesWritten;
}

bool FHermesAssetExporter::PromptAndExportSelection()
{
	// Read the active Content Browser selection.
	FContentBrowserModule& ContentBrowserModule =
		FModuleManager::LoadModuleChecked<FContentBrowserModule>(TEXT("ContentBrowser"));
	IContentBrowserSingleton& ContentBrowser = ContentBrowserModule.Get();

	TArray<FAssetData> SelectedAssets;
	ContentBrowser.GetSelectedAssets(SelectedAssets);

	if (SelectedAssets.Num() == 0)
	{
		FNotificationInfo Info(NSLOCTEXT("HermesAssetExporter", "NothingSelected",
			"Hermes export: nothing selected in the Content Browser"));
		Info.ExpireDuration = 4.0f;
		Info.bUseSuccessFailIcons = true;
		FSlateNotificationManager::Get().AddNotification(Info)
			->SetCompletionState(SNotificationItem::CS_Fail);
		return false;
	}

	// Ask the user where to write the export.
	IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
	if (!DesktopPlatform)
	{
		UE_LOG(LogHermesExporter, Error, TEXT("DesktopPlatform unavailable — cannot show folder picker"));
		return false;
	}

	const void* ParentWindowHandle = nullptr;
	if (FSlateApplication::IsInitialized())
	{
		// Best-effort: pass the main editor window as the dialog parent so
		// the OS treats the picker as modal to the editor.
		TSharedPtr<SWindow> MainWindow = FSlateApplication::Get().GetActiveTopLevelWindow();
		if (MainWindow.IsValid() && MainWindow->GetNativeWindow().IsValid())
		{
			ParentWindowHandle = MainWindow->GetNativeWindow()->GetOSWindowHandle();
		}
	}

	FString TargetDirectory;
	const FString DefaultPath = FPaths::Combine(FPaths::ProjectDir(), TEXT("HermesExports"));
	const bool bPicked = DesktopPlatform->OpenDirectoryDialog(
		ParentWindowHandle,
		NSLOCTEXT("HermesAssetExporter", "PickDirTitle", "Choose export destination").ToString(),
		DefaultPath,
		TargetDirectory);

	if (!bPicked)
	{
		UE_LOG(LogHermesExporter, Log, TEXT("Export cancelled by user"));
		return false;
	}

	ExportSelectedAssets(SelectedAssets, TargetDirectory, /*bIncludeDependencies*/ true);
	return true;
}

void FHermesAssetExporter::PromptAndExportSelectionVoid()
{
	// FExecuteAction and FConsoleCommandDelegate both bind to void(void). The
	// bool result of PromptAndExportSelection is meaningful but neither binding
	// site consumes it, so discard it here.
	PromptAndExportSelection();
}
