// Copyright (c) 2026 Justin. All Rights Reserved.

#include "HermesPanel.h"
#include "HermesManager.h"
#include "Widgets/Layout/SBorder.h"
#include "SWebBrowser.h"
#include "Styling/AppStyle.h"
#include "Async/Async.h"

void SHermesPanel::Construct(const FArguments& InArgs)
{
	HermesManager = InArgs._HermesManager;

	FString URL = TEXT("about:blank");
	if (HermesManager.IsValid())
	{
		HermesManager->Initialize();
		URL = HermesManager->GetHermesURL();
	}

	ChildSlot
	[
		SNew(SBorder)
		.BorderImage(FAppStyle::GetBrush("ToolPanel.GroupBorder"))
		.Padding(2.0f)
		[
			SAssignNew(WebBrowser, SWebBrowser)
			.InitialURL(URL)
			.ShowControls(true)
			.ShowAddressBar(false)
			.SupportsTransparency(false)
		]
	];

	TWeakPtr<FHermesManager> WeakManager = HermesManager;
	if (!WeakManager.IsValid() || !WeakManager.Pin()->IsHermesRunning())
	{
		Async(EAsyncExecution::ThreadPool, [WeakManager]()
		{
			for (int32 Attempt = 0; Attempt < 24; ++Attempt)
			{
				FPlatformProcess::Sleep(0.5f);
				if (WeakManager.IsValid() && WeakManager.Pin()->IsHermesRunning())
				{
					break;
				}
			}
		});
	}
}
