// Copyright (c) 2026 Justin. All Rights Reserved.
//
// HermesAssetExporter.h
//
// Editor-only utility that copies selected Content Browser assets (plus their
// hard package dependencies) to a folder the user picks on disk. The on-disk
// copies are real .uasset / .umap / .uexp / .ubulk files that can be
// re-imported into another Unreal project.
//
// Why this exists: the Fab listing page surfaces a yellow "exporting Unreal
// Engine files is not yet supported" warning unless the plugin demonstrates
// the ability to write .uasset files out. This exporter is the substantive
// implementation behind that capability.

#pragma once

#include "CoreMinimal.h"

struct FAssetData;

/**
 * Static helper that performs the asset export.
 *
 * Workflow:
 *  1. Caller gathers FAssetData (typically from the Content Browser selection).
 *  2. ExportSelectedAssets() resolves the package dependency closure via the
 *     Asset Registry, then copies each on-disk package file to the target
 *     directory, preserving the /Game/... layout under the chosen folder.
 *  3. Returns the number of distinct files written and the destination path.
 *
 * The function is safe to call with an empty selection — it logs a warning and
 * returns zero. It is also safe to call from the editor's main thread only;
 * long copies are offloaded to a background thread internally and a UI
 * notification is fired on completion.
 */
class FHermesAssetExporter
{
public:
	/**
	 * Export the given assets to TargetDirectory.
	 *
	 * @param SelectedAssets  Assets to export (typically from Content Browser).
	 * @param TargetDirectory Absolute filesystem path to the destination folder.
	 * @param bIncludeDependencies  If true, recursively include hard package references.
	 * @return Number of distinct files written to disk (uasset + sidecar files).
	 */
	static int32 ExportSelectedAssets(
		const TArray<FAssetData>& SelectedAssets,
		const FString& TargetDirectory,
		bool bIncludeDependencies = true);

	/**
	 * Convenience: read the current Content Browser selection and export it
	 * to a folder the user picks via the platform folder-picker dialog.
	 * Shows a notification on completion.
	 *
	 * @return true if the user picked a folder and the export ran, false if
	 *         the user cancelled the dialog.
	 */
	static bool PromptAndExportSelection();

	/**
	 * Void-returning wrapper. FExecuteAction and FConsoleCommandDelegate both
	 * expect void(void) signatures, so menu/console bindings use this entry
	 * point and the bool result is dropped.
	 */
	static void PromptAndExportSelectionVoid();
};
